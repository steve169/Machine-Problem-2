import pyglet
import random
from pyglet.window import mouse
window = pyglet.window.Window(width = 900, height = 600)

#includes the wallpapers
wallpaper1 = pyglet.image.load('wallpaper1.jpg')
wallpaper2 = pyglet.image.load('wallpaper2.jpg')
wallpapers = [wallpaper1, wallpaper2]

screen = random.randint(0, 1)   # generates which wallpaper to be used

pyglet.font.add_file('Pokemon Solid.ttf')
Pokemon_Solid = pyglet.font.load('Pokemon Solid')
# puts all available pokemons into a list
pokemonlist = []
file_stream= open('pokemon.txt')
for word in file_stream:
    pokemonlist.append(word.strip())

# puts all available pokeball art into a list
pokeballlist = []
file_stream= open('pokeball.txt')
for word in file_stream:
    pokeballlist.append(word.strip())

def startscreen():
    welcome = pyglet.text.Label('Welcome to Who\'s That Pokemon!',
            font_name='Pokemon Solid',
            color = (255, 0, 0, 255),
            font_size=36,
            x= window.width // 2,
            y= window.height // 2,
            anchor_x='center',
            anchor_y='center')

    go_on = pyglet.text.Label('Click anywhere to continue',
            font_name='Century Gothic',
            font_size=18,
            color=(255, 0, 0, 255),
            x= window.width // 2,
            y= 200,
            anchor_x= 'center')

    wallpaper = pyglet.sprite.Sprite(wallpapers[screen])

    @window.event
    def on_draw():
        window.clear()
        wallpaper.draw()
        welcome.draw()
        go_on.draw()

    @window.event
    def on_mouse_press(x, y, button, modifiers):  # goes to the menu page
        if button == mouse.LEFT:
            terminalscreen()
def difficultyscreen():
    difficulty = pyglet.text.Label('Select Difficulty',
                               font_name='Pokemon Solid',
                               font_size=36,
                               color=(255, 0, 0, 255),
                               x=window.width // 2,
                               y=500,
                               anchor_x='center')

    easy = pyglet.text.Label('EASY',
                               font_name='Pokemon Solid',
                               font_size=26,
                               color=(255, 0, 0, 255),
                               x=window.width // 2,
                               y=100,
                               anchor_x='center')

    average = pyglet.text.Label('AVERAGE',
                             font_name='Pokemon Solid',
                             font_size=26,
                             color=(255, 0, 0, 255),
                             x=window.width // 2,
                             y=200,
                             anchor_x='center')

    difficult = pyglet.text.Label('DIFFICULT',
                             font_name='Pokemon Solid',
                             font_size=26,
                            color=(255, 0, 0, 255),
                             x=window.width // 2,
                             y=300,
                             anchor_x='center')

    lunatic = pyglet.text.Label('LUNATIC',
                                  font_name='Pokemon Solid',
                                  font_size=26,
                                color=(255, 0, 0, 255),
                                  x=window.width // 2,
                                  y=400,
                                  anchor_x='center')
    back = pyglet.text.Label('BACK',
                             font_name='Pokemon Solid',
                             font_size=28,
                             color=(255, 0, 0, 255),
                             x=50,
                             y=20)

    wallpaper = pyglet.sprite.Sprite(wallpapers[screen])

    @window.event
    def on_draw():
        window.clear()
        wallpaper.draw()
        difficulty.draw()
        easy.draw()
        average.draw()
        difficult.draw()
        lunatic.draw()
        back.draw()

    @window.event
    def on_mouse_press(x, y, button, modifiers):
        if button == mouse.LEFT and 20 < y < 50 and 50 < x < 160: # back function
            terminalscreen()
        if window.width // 2 - 200 < x < window.width // 2 + 200 and 80 < y < 120:
            poke(4)
        elif window.width//2- 200 <x< window.width//2 + 200 and 180 <y< 220:
            poke(6)
        elif window.width//2- 200 <x< window.width//2 + 200 and 280<y<320:
            poke(8)
        elif window.width//2- 200 <x<window.width//2+ 200 and 380<y<420:
            poke(10)
def mechanical():
    intro = pyglet.text.Label('Memory has long been a favorite game for all generations.',
                                   font_name='Century Gothic',
                                   font_size=14,
                                   color=(255, 0, 255, 255),
                                   x=12,
                                   y=550,)

    intro1 = pyglet.text.Label('It is easy to play, in fact it is so simple',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=12,
        y=525, )

    intro2 = pyglet.text.Label('that really young children can play with ease. It requires ',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=12,
        y=500, )
    intro3 = pyglet.text.Label('observation, concentration and a good memory to win.',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=12,
        y=475, )

    intro4 = pyglet.text.Label('"Who\'s that Pokemon?" is a game that is played using pokeballs instead of cards.',
                               font_name='Century Gothic',
                               font_size=14,
                               color=(255, 0, 255, 255),
                               x=12,
                               y=450, )

    intro5 = pyglet.text.Label('MECHANICS:',
                               font_name='Century Gothic',
                               font_size=18,
                               color=(255, 0, 255, 255),
                               x=12,
                               y=400, )

    intro6 = pyglet.text.Label('1) Each player needs to choose which level to play. There would be 4 levels to choose from:',
                               font_name='Century Gothic',
                               font_size=14,
                               color=(255, 0, 255, 255),
                               x=12,
                               y=375, )

    intro62 = pyglet.text.Label('EASY, AVERAGE, DIFFICULT, LUNATIC',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=35,
        y=360, )

    intro7 = pyglet.text.Label('2) The player needs to flip the pokeballs with corresponding pokemons. It is required to match all the pokemons',
                               font_name='Century Gothic',
                               font_size=14,
                               color=(255, 0, 255, 255),
                               x=12,
                               y=335, )

    intro72 = pyglet.text.Label('in order to finish the level.',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=12,
        y=320, )

    intro8 = pyglet.text.Label('3) The player will be limited to flip only one pokeball at a time. If the revealed pokeball do not match the',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=12,
        y=295, )

    intro82 = pyglet.text.Label('other flipped pokeball, the pokeballs will flip back again.',
        font_name='Century Gothic',
        font_size=14,
        color=(255, 0, 255, 255),
        x=12,
        y=280, )

    intro9 = pyglet.text.Label('4) Each pair of matched pokemons corresponds to 10 points.',
                                font_name='Century Gothic',
                                font_size=14,
                                color=(255, 0, 255, 255),
                                x=12,
                                y=255, )

    intro10 = pyglet.text.Label('5) The game will end once all the pokemons are all matched.',
                               font_name='Century Gothic',
                               font_size=14,
                               color=(255, 0, 255, 255),
                               x=12,
                               y=230, )

    back = pyglet.text.Label('BACK',
                             font_name='Pokemon Solid',
                             color=(255, 0, 0, 255),
                             font_size=28,
                             x=50,
                             y=20)

    wallpaper = pyglet.sprite.Sprite(wallpapers[screen])

    @window.event
    def on_draw():
        window.clear()
        wallpaper.draw()
        intro.draw()
        intro1.draw()
        intro2.draw()
        intro3.draw()
        intro4.draw()
        intro5.draw()
        intro6.draw()
        intro62.draw()
        intro7.draw()
        intro72.draw()
        intro8.draw()
        intro82.draw()
        intro9.draw()
        intro10.draw()
        back.draw()

    @window.event
    def on_mouse_press(x, y, button, modifiers):
        if button == mouse.LEFT and 20 < y < 50 and 50 < x < 160:  # back function
            terminalscreen()

def terminalscreen():
    difficulty = pyglet.text.Label('START',
                                   font_name='Pokemon Solid',
                                   font_size=36,
                                   color=(255, 0, 0, 255),
                                   x=window.width // 2,
                                   y=500,
                                   anchor_x='center')

    quit = pyglet.text.Label('QUIT',
                             font_name='Pokemon Solid',
                             font_size=36,
                             color=(255, 0, 0, 255),
                             x=window.width // 2,
                             y=100,
                             anchor_x='center')

    mechanics = pyglet.text.Label('MECHANICS',
                             font_name='Pokemon Solid',
                             font_size=36,
                            color=(255, 0, 0, 255),
                             x=window.width // 2,
                             y=300,
                             anchor_x='center')

    back = pyglet.text.Label('BACK',
                             font_name='Pokemon Solid',
                             color=(255, 0, 0, 255),
                             font_size=28,
                             x=50,
                             y=20)

    wallpaper = pyglet.sprite.Sprite(wallpapers[screen])

    @window.event
    def on_draw():
        window.clear()
        wallpaper.draw()
        difficulty.draw()
        mechanics.draw()
        quit.draw()
        back.draw()
    @window.event
    def on_mouse_press(x, y, button, modifiers):
        if button == mouse.LEFT and 480 < y < 520: # goes to the difficulty menu
            difficultyscreen()
        elif button == mouse.LEFT and 20 < y < 50 and 50 < x < 160: # back function
            startscreen()
        elif button == mouse.LEFT and 90 < y < 140 and 400 < x < 500: # quits the program
            exit()
        elif button == mouse.LEFT and 280 < y < 320 and 300 < x < 600:  # quits the program
            mechanical()

def aftergame():
    thank = pyglet.text.Label('Thank You for Playing',
                                   font_name='Times New Roman',
                                   font_size=36,
                                   color=(255, 0, 0, 255),
                                   x=window.width // 2,
                                   y=500,
                                   anchor_x='center')

    repeat = pyglet.text.Label('Would you like to play again?',
                                   font_name='Times New Roman',
                                   font_size=36,
                                   color=(255, 0, 0, 255),
                                   x=window.width // 2,
                                   y=400,
                                   anchor_x='center')

    yes = pyglet.text.Label('YES',
                               font_name='Times New Roman',
                               font_size=24,
                               color=(255, 0, 0, 255),
                               x=window.width // 2,
                               y=300,
                               anchor_x='center')

    no = pyglet.text.Label('NO',
                            font_name='Times New Roman',
                            font_size=24,
                            color=(255, 0, 0, 255),
                            x=window.width // 2,
                            y=200,
                            anchor_x='center')

    @window.event
    def on_draw():
        window.clear()
        wallpaper.draw()
        thank.draw()
        repeat.draw()
        yes.draw()
        no.draw()

    @window.event
    def on_mouse_press(x, y, button, modifiers):
        if button == mouse.LEFT and 280 < y < 320 and 420 < x < 480:  # back function
            difficultyscreen()
        elif button == mouse.LEFT and 180 < y < 220 and 420 < x < 480:  # quits the program
            exit()

def poke(diff):
    number = diff ** 2   # refers to the difficulty
    usablepoke = []      # pokemons to be used in this game
    wallpaper = pyglet.sprite.Sprite(wallpapers[screen])
    for j in range(int(number/2)):
        rndint = random.randint(0, len(pokemonlist) - 1)
        usablepoke.append(pokemonlist[rndint])   # append the pokemon twice
        usablepoke.append(pokemonlist[rndint])

    scaling = 1/diff * 2.3
    scalex = 720 / diff
    scaley = 540 / diff
    pics = []      # pokemon, but in their position
    for j in range(diff):
        for k in range(diff):
            l = random.randint(0, len(usablepoke) - 1)
            pokemon = pyglet.image.load(usablepoke[l])
            xcoor = 90 + scalex * k         # places the pokemon into their position
            ycoor = 25 + scaley * j
            pokemonsprite = pyglet.sprite.Sprite(pokemon)
            usablepoke.remove(usablepoke[l])
            pokemonsprite.scale = scaling*0.8    # scales the pokemon
            pokemonsprite.position = (xcoor, ycoor)
            pics.append(pokemonsprite)

    rndint = random.randint(0, len(pokeballlist) - 1)
    ball = []    #  puts the available pokeballs into a list
    for j in range(number):
        ball.append(pokeballlist[rndint])

    ballpics = []
    for j in range(diff):   # same as pokemon but for pokeballs
        for k in range(diff):
            l = random.randint(0, len(ball) - 1)
            pokeball = pyglet.image.load(ball[l])
            xcoor = 50 + scalex * k
            ycoor = scaley * j
            pokeballsprite = pyglet.sprite.Sprite(pokeball)
            pokeballsprite.scale = scaling/1.8
            pokeballsprite.position = (xcoor, ycoor)
            ballpics.append(pokeballsprite)


    @window.event
    def on_draw():
        window.clear()
        wallpaper.draw()
        for k in range(len(pics)):
            ballpics[k].draw()

    @window.event
    def on_mouse_press(x, y, button, modifiers):
        c=[]
        for b in range(2):
            if button == mouse.LEFT and 62 <= x <= 900 and y <= 600:
                xpoint1 = (x - 62) // scalex
                ypoint1 = y // scaley
                pokemon1 = int(ypoint1 * diff + xpoint1)
                @window.event
                def on_draw():
                    window.clear()
                    wallpaper.draw()
                    pics[pokemon1].draw()
                    for k in range(len(pics)):
                        if k != pokemon1:
                            ballpics[k].draw()
                    c.append(pics[pokemon1])
    if c[0] != c[1]:
            window.clear()
    else:
        for d in range(2):
            c[d].draw()

