import pyglet
import interfacee
from pyglet.window import mouse


interfacee.startscreen()
pyglet.app.run()